// mobina najafi
// 40223081


#include<stdio.h>
#include<math.h>

void solver(double a,double b,double c,double* ptr1 ,double* ptr2,double* dlta){
   
    double delta;
    delta=(b*b) - (4*a*c);
    
    if(delta>0){
        *dlta = 2;
        *ptr1 = ((-b)+ sqrt(delta))/(2*a);
        *ptr2 = ((-b)- sqrt(delta))/(2*a);
    }
    else if (delta<0)
        *dlta = 0;
    
    else if(delta==0){
        *dlta =1 ;
        *ptr1 = (-b)/(2*a);
    }
    
}

int main(){
    
    double a,b,c, ans1, ans2, deltaa;
    printf("enter 3 real numbers:\n");
    scanf("%lf%lf%lf", &a,&b,&c);
    
    if (a==0 && b==0){
        printf("your inputs are wrong!!\n");
        return 0;
    }

    
    solver(a,b,c,&ans1,&ans2,&deltaa);
    
    if(deltaa==1){
        printf("this equation has 1 real root\n");
        printf("%lf\n",ans1 );
    }
    if (deltaa==0){
        printf("this equation has no real roots\n");
    }
    if (deltaa==2){
        printf("this equation has 2 real roots\n");
        printf("%lf\n%lf\n",ans1,ans2 );
    }
    
}


